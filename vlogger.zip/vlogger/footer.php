<?php
/*
Package: Vlogger
*/
?>
			
			</div>
		 <?php wp_footer(); ?>
 		</body>
</html>
