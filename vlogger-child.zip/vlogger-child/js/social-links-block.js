const { registerBlockType } = wp.blocks;
const { createElement } = wp.element;

registerBlockType('custom/social-links', {
    title: 'Social Links',
    description: 'A block to display social media links.',
    category: 'widgets',
    icon: 'megaphone',
    edit: () => {
        return createElement(
            'p',
            { style: { fontWeight: 'bold', textAlign: 'center' } },
            '¡SÍGUENOS EN NUESTRAS REDES SOCIALES!'
        );
    },
    save: () => {
        return createElement(
            'div',
            { className: 'social-links' },
            createElement('div', { style: { height: '35px' }, 'aria-hidden': 'true', className: 'wp-block-spacer' }),
            createElement('hr', { className: 'wp-block-separator has-alpha-channel-opacity' }),
            createElement('div', { style: { height: '35px' }, 'aria-hidden': 'true', className: 'wp-block-spacer' }),
            createElement(
                'p',
                { style: { fontStyle: 'normal', fontWeight: 800 } },
                createElement('strong', null, '¡SÍGUENOS EN NUESTRAS REDES SOCIALES Y NO TE PIERDAS DE NADA!'),
                createElement('img', {
                    draggable: 'false',
                    role: 'img',
                    className: 'emoji',
                    alt: ':rocket:',
                    src: 'https://s.w.org/images/core/emoji/15.0.3/svg/1f680.svg',
                })
            ),
            createElement('div', { style: { height: '35px' }, 'aria-hidden': 'true', className: 'wp-block-spacer' }),
            // Lista de enlaces
            createElement(
                'a',
                {
                    href: 'https://www.tiktok.com/@contraplanotv?is_from_webapp=1&sender_device=pc',
                    className: 'social-link tiktok',
                    target: '_blank',
                    rel: 'noopener',
                },
                'TikTok'
            ),
            createElement(
                'a',
                {
                    href: 'https://www.tiktok.com/@contraplano_?is_from_webapp=1&sender_device=pc',
                    className: 'social-link tiktok2',
                    target: '_blank',
                    rel: 'noopener',
                },
                'TikTok 2'
            ),
            createElement(
                'a',
                {
                    href: 'https://x.com/ContraplanoTv',
                    className: 'social-link x-twitter',
                    target: '_blank',
                    rel: 'noopener',
                },
                'X (Twitter)'
            ),
            createElement(
                'a',
                {
                    href: 'https://www.instagram.com/contraplano_/',
                    className: 'social-link instagram',
                    target: '_blank',
                    rel: 'noopener',
                },
                'Instagram'
            ),
            createElement(
                'a',
                {
                    href: 'https://www.facebook.com/periodico.contraplano',
                    className: 'social-link facebook',
                    target: '_blank',
                    rel: 'noopener',
                },
                'Facebook'
            ),
            createElement(
                'a',
                {
                    href: 'https://cl.linkedin.com/in/contraplano-medios-de-comunicacion-periodico-tv',
                    className: 'social-link linkedin',
                    target: '_blank',
                    rel: 'noopener',
                },
                'LinkedIn'
            ),
            createElement(
                'a',
                {
                    href: 'https://www.whatsapp.com/channel/0029VaOv2xdBA1eqf5k1Gr3B',
                    className: 'social-link whatsapp',
                    target: '_blank',
                    rel: 'noopener',
                },
                'WhatsApp'
            ),
            createElement(
                'a',
                {
                    href: 'https://www.youtube.com/@contraplanomedios',
                    className: 'social-link youtube',
                    target: '_blank',
                    rel: 'noopener',
                },
                'YouTube'
            ),
            createElement(
                'a',
                {
                    href: 'https://issuu.com/periodicocontraplano',
                    className: 'social-link issuu',
                    target: '_blank',
                    rel: 'noopener',
                },
                'Issuu'
            ),
            createElement(
                'a',
                {
                    href: 'https://radiocontraplano.cl/',
                    className: 'social-link radiocp',
                    target: '_blank',
                    rel: 'noopener',
                },
                'Radio ContraPlano'
            ),
            createElement('div', { style: { height: '35px' }, 'aria-hidden': 'true', className: 'wp-block-spacer' }),
            createElement('hr', { className: 'wp-block-separator has-alpha-channel-opacity' }),
            createElement(
                'div',
                { className: 'image-container' },
                createElement('img', {
                    src: 'https://contraplano.cl/wp-content/uploads/2024/11/cropped-logosolopajaronblanco123.png',
                    alt: 'Logo Radio ContraPlano',
                    className: 'wp-image-1649',
                })
            ),
            createElement('div', { style: { height: '35px' }, 'aria-hidden': 'true', className: 'wp-block-spacer' })
        );
    },
});
