document.addEventListener('DOMContentLoaded', function() {
    // Selecciona el contenedor con la clase 'qt-the-content'
    const contentContainer = document.querySelector('.qt-the-content');
    if (contentContainer) {
        // Reemplaza todas las etiquetas <br> con un espacio
        contentContainer.innerHTML = contentContainer.innerHTML.replace(/<br\s*\/?>/gi, ' ');
    }
});
