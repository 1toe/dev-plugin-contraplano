<?php  
/**
 *  Vlogger Child theme
 * custom functions.php file
 */

/**
 * Add parent and child stylesheets
 */
add_action( 'wp_enqueue_scripts', 'vlogger_child_enqueue_styles' );
if(!function_exists('vlogger_child_enqueue_styles')) {
function vlogger_child_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_uri() );
}}

/**
 * Upon activation flush the rewrite rules to avoid 404 on custom post types
 */
add_action( 'after_switch_theme', 'vlogger_child_rewrite_flush_child' );
if(!function_exists('vlogger_child_rewrite_flush_child')) {
function vlogger_child_rewrite_flush_child() {
    flush_rewrite_rules();
}}	


/**
 * Setup Onair2 Child Theme's textdomain.
 *
 * Declare textdomain for this child theme.
 * Translations can be filed in the /languages/ directory.
 */
function vlogger_child_theme_setup() {
	load_child_theme_textdomain( 'vlogger-child',  get_stylesheet_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'vlogger_child_theme_setup' );


// Widget Social Links
function register_social_links_block() {
    // Registrar el bloque 
    wp_register_script(
        'social-links-block',
        get_stylesheet_directory_uri() . '/js/social-links-block.js',
        ['wp-blocks', 'wp-element', 'wp-editor'],
        filemtime(get_stylesheet_directory() . '/js/social-links-block.js')
    );

    // Registrar el tipo de bloque 
    register_block_type('custom/social-links', [
        'editor_script'   => 'social-links-block',
        'render_callback' => 'render_social_links_block',
    ]);
}
add_action('init', 'register_social_links_block');

// Redirección automática de las series 
function agregar_scripts_customizados() {
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Agregar el código JavaScript aquí para redirigir al hacer clic en la tarjeta
        document.querySelectorAll('.qt-part-archive-item').forEach(function(item) {
            item.addEventListener('click', function(e) {
                // Verifica si el clic no fue en un enlace ya
                if (!e.target.closest('a')) {
                    window.location.href = item.querySelector('a').href;
                }
            });
        });
        document.querySelectorAll('.qt-activate-card').forEach(function(card) {
            card.addEventListener('click', function(event) {
                // Evita que el clic en la tarjeta active otro comportamiento, como "Start Now"
                event.preventDefault();
                window.location.href = card.href;
            });
        });
    });
    </script>
    <?php
}
add_action('wp_footer', 'agregar_scripts_customizados');

function deshabilitar_autodimension_youtube() {
    ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const iframes = document.querySelectorAll('iframe[src*="youtube.com"]');
            iframes.forEach(iframe => {
                // Elimina los atributos que establecen dimensiones predeterminadas
                iframe.removeAttribute('width');
                iframe.removeAttribute('height');

                // Aplica dimensiones personalizadas
                iframe.style.width = '100%';
                iframe.style.height = (iframe.parentElement.offsetWidth * 9 / 16) + 'px'; // Mantén proporción 16:9
            });

            // Ajusta en tiempo real si cambia el tamaño de la ventana
            window.addEventListener('resize', () => {
                iframes.forEach(iframe => {
                    iframe.style.height = (iframe.parentElement.offsetWidth * 9 / 16) + 'px';
                });
            });
        });
    </script>
    <?php
}
add_action('wp_footer', 'deshabilitar_autodimension_youtube');

function agregar_js_personalizado() {
    ?>
    <script type="text/javascript">
        // Seleccionamos todos los elementos con el atributo 'data-vc-video-bg'
        document.querySelectorAll('[data-vc-video-bg]').forEach(function(element) {
            // Añadimos un event listener a cada uno de los elementos
            element.addEventListener('click', function() {
                // Obtener el valor del atributo 'data-vc-video-bg'
                var categoryUrl = ''; // Inicializamos la variable de la URL
                var videoUrl = element.getAttribute('data-vc-video-bg');

                if (videoUrl === 'https://www.youtube.com/watch?v=5Mv5xoz08Mo') {
                    categoryUrl = 'https://contraplano.cl/category/medio-ambiente/';
                } else if (videoUrl === 'https://www.youtube.com/watch?v=Us7fer3zqWk') {
                    categoryUrl = 'https://contraplano.cl/category/gaming/';
                } else if (videoUrl === 'https://www.youtube.com/watch?v=wQHJymrkA-0') {
                    categoryUrl = 'https://contraplano.cl/category/famosos/';
                }

                if (categoryUrl) {
                    window.location.href = categoryUrl;
                }
            });
        });
    </script>
    <?php
}

add_action('wp_footer', 'agregar_js_personalizado');

function modificar_slider_timeout() {
    ?>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            // Seleccionar el slider por su clase
            var sliders = document.querySelectorAll('.slider.qt-material-slider.qt-hero-slider');
            sliders.forEach(function(slider) {
                // Cambiar el valor de data-timeout a 6000
                slider.setAttribute('data-timeout', '6000');
            });
        });
    </script>
    <?php
}
add_action('wp_footer', 'modificar_slider_timeout');

function agregar_font_awesome() {
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css', array(), '6.0.0', 'all' );
}
add_action( 'wp_enqueue_scripts', 'agregar_font_awesome' );

function enqueue_replace_br_script() {
    if (is_single()) { // Asegura que el script se cargue solo en entradas individuales
        wp_enqueue_script(
            'replace-br-script', // Nombre único del script
            get_template_directory_uri() . '/js/replace-br.js', // Ruta al archivo JS
            array(), // Dependencias (vacío si no hay dependencias)
            '1.0', // Versión del script
            true // Cargar en el footer
        );
    }
}
add_action('wp_enqueue_scripts', 'enqueue_replace_br_script');