<?php
/**
 * Plugin Name: Flipbook Contraplano
 * Description: Visualiza Flipbooks PDF interactivos. Incluye zonas interactivas y audio en ediciones especiales.
 * Version: 1.1
 * Author: a
 */

if (!defined('ABSPATH')) exit;

// Define constants for plugin paths and URLs
define('FP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('FP_PLUGIN_URL', plugin_dir_url(__FILE__));

// 1. Registrar tipo de contenido personalizado
function fp_register_flipbook_post_type() {
    register_post_type('flipbook', [
        'labels' => [
            'name' => 'Flipbooks',
            'singular_name' => 'Flipbook',
            'add_new' => 'Agregar nuevo',
            'add_new_item' => 'Agregar nuevo Flipbook',
            'edit_item' => 'Editar Flipbook',
            'new_item' => 'Nuevo Flipbook',
            'view_item' => 'Ver Flipbook',
            'search_items' => 'Buscar Flipbook',
            'not_found' => 'No encontrado',
        ],
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-book',
        'supports' => ['title'],
        'rewrite' => ['slug' => 'flipbooks'],
    ]);
}
add_action('init', 'fp_register_flipbook_post_type');

// 2. Agregar metabox para subir PDF y audio
function fp_add_meta_box() {
    add_meta_box('fp_meta_box', 'Configuración del Flipbook', 'fp_meta_callback', 'flipbook', 'normal', 'high');
}
add_action('add_meta_boxes', 'fp_add_meta_box');

function fp_meta_callback($post) {
    wp_nonce_field('fp_save_meta_data', 'fp_meta_nonce');

    $pdf = get_post_meta($post->ID, 'fp_pdf', true);
    $audio = get_post_meta($post->ID, 'fp_audio', true);

    ?>
    <p>
        <label for="fp_pdf">PDF del Flipbook:</label><br>
        <input type="text" name="fp_pdf" id="fp_pdf" value="<?php echo esc_url($pdf); ?>" style="width:80%;" readonly>
        <button type="button" class="button" id="fp_pdf_button">Subir o seleccionar PDF</button>
        <?php if ($pdf): ?>
            <p><small>URL actual: <?php echo esc_url($pdf); ?></small></p>
        <?php endif; ?>
    </p>
    <p>
        <label for="fp_audio">Audio del Flipbook (Opcional):</label><br>
        <input type="text" name="fp_audio" id="fp_audio" value="<?php echo esc_url($audio); ?>" style="width:80%;" readonly>
        <button type="button" class="button" id="fp_audio_button">Subir o seleccionar Audio</button>
         <?php if ($audio): ?>
            <p><small>URL actual: <?php echo esc_url($audio); ?></small></p>
        <?php endif; ?>
    </p>
    <?php
}

function fp_save_meta($post_id) {
    if (!isset($_POST['fp_meta_nonce']) || !wp_verify_nonce($_POST['fp_meta_nonce'], 'fp_save_meta_data')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['fp_pdf'])) {
        update_post_meta($post_id, 'fp_pdf', sanitize_url($_POST['fp_pdf']));
    } else {
         delete_post_meta($post_id, 'fp_pdf');
    }

    if (isset($_POST['fp_audio'])) {
        update_post_meta($post_id, 'fp_audio', sanitize_url($_POST['fp_audio']));
    } else {
        delete_post_meta($post_id, 'fp_audio');
    }
}
add_action('save_post_flipbook', 'fp_save_meta');

// 3. Encolar script para media uploader en admin
add_action('admin_enqueue_scripts', function($hook) {
    global $post_type;
    if (($hook !== 'post.php' && $hook !== 'post-new.php') || 'flipbook' !== $post_type) {
        return;
    }

    wp_enqueue_media();

    wp_add_inline_script('jquery', <<<JS
    jQuery(document).ready(function($) {
        function setupMediaUploader(buttonId, inputId, mediaTitle, mediaButtonText, mediaType) {
            $('#' + buttonId).on('click', function(e) {
                e.preventDefault();
                var frame = wp.media({
                    title: mediaTitle,
                    button: { text: mediaButtonText },
                    multiple: false,
                    library: mediaType ? { type: mediaType } : undefined
                });
                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    $('#' + inputId).val(attachment.url);
                    $('#' + inputId).next('p').remove();
                    $('#' + inputId).after('<p><small>URL actual: ' + attachment.url + '</small></p>');
                });
                frame.open();
            });
        }

        setupMediaUploader('fp_pdf_button', 'fp_pdf', 'Selecciona o sube un PDF', 'Usar este PDF', 'application/pdf');
        setupMediaUploader('fp_audio_button', 'fp_audio', 'Selecciona o sube un archivo de audio', 'Usar este Audio', 'audio');
    });
JS);
});

// 4. Encolar scripts y estilos para el frontend (SOLO si se usa el shortcode)
function fp_enqueue_frontend_assets() {
    $pdfjs_version = '2.10.377';
    wp_enqueue_script('pdfjs-lib', "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/$pdfjs_version/pdf.min.js", [], $pdfjs_version, true);
    wp_enqueue_script('pdfjs-worker', "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/$pdfjs_version/pdf.worker.min.js", [], $pdfjs_version, true);

    wp_enqueue_style('fp-front-style', FP_PLUGIN_URL . 'css/fp-front.css', [], '1.0');
    wp_enqueue_script('fp-front-script', FP_PLUGIN_URL . 'js/fp-front.js', ['jquery', 'pdfjs-lib', 'pdfjs-worker'], '1.0', true);

    wp_localize_script('fp-front-script', 'fpConfig', [
       'pdfWorkerSrc' => "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/$pdfjs_version/pdf.worker.min.js"
    ]);
}

// 5. Mostrar el Flipbook en el frontend via Shortcode
function fp_flipbook_shortcode($atts) {
    $atts = shortcode_atts([
        'id' => '',
    ], $atts, 'flipbook');

    $post_id = absint($atts['id']);

    if (!$post_id || get_post_type($post_id) !== 'flipbook') {
        return '<p>Error: Flipbook ID inválido o no encontrado.</p>';
    }

    $pdf = get_post_meta($post_id, 'fp_pdf', true);
    $audio = get_post_meta($post_id, 'fp_audio', true);

    if (empty($pdf)) {
         return '<p>Error: No se ha configurado un PDF para este Flipbook.</p>';
    }

    fp_enqueue_frontend_assets();

    $container_id = 'flipbook-container-' . $post_id . '-' . wp_rand(100, 999);

    ob_start(); // Etiqueta de inicio de salida para capturar el HTML generado dentro
    ?>
    <div id="<?php echo esc_attr($container_id); ?>" class="flipbook-container" data-pdf="<?php echo esc_url($pdf); ?>" <?php if ($audio): ?>data-audio="<?php echo esc_url($audio); ?>"<?php endif; ?>>
        <!-- Flechas de navegación -->
        <button class="fp-arrow fp-arrow-left" style="display:none;">&larr;</button>
        <div id="fp-pdf-viewer-<?php echo esc_attr($post_id); ?>" class="fp-pdf-viewer">
             <div class="fp-loading">Cargando Flipbook...</div>
             <div id="fp-pages-container-<?php echo esc_attr($post_id); ?>" class="fp-pages-container" style="display:none;">
             </div>
        </div>
        <button class="fp-arrow fp-arrow-right" style="display:none;">&rarr;</button>

        <?php if ($audio): ?>
        <div id="fp-audio-container-<?php echo esc_attr($post_id); ?>" class="fp-audio-container">
            <audio controls src="<?php echo esc_url($audio); ?>">
                Tu navegador no soporta el elemento de audio.
            </audio>
        </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('flipbook', 'fp_flipbook_shortcode');

function fp_delete_post_meta($post_id) {
    if (get_post_type($post_id) === 'flipbook') {
        delete_post_meta($post_id, 'fp_pdf');
        delete_post_meta($post_id, 'fp_audio');
    }
}
add_action('delete_post', 'fp_delete_post_meta');

?>